Middleware.jar is the executable middleware application
It is invoked by java -jar Middleware.jar <PO folder path>

Middleware.zip is the source file that is to be imported into eclipse

Both were added for brevity.
